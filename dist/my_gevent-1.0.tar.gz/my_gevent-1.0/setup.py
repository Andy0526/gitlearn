from distutils.core import setup
setup(name='my_gevent',
      version='1.0',
      py_modules=['my_gevent'],
      )  
